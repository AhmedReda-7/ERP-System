﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GP_ERP_SYSTEM_v1._0.DTOs
{
    public class CreateOrderDTO
    {
        public int MaterialId { get; set; }
        public int MaterialQuantity { get; set; }

    }
}
