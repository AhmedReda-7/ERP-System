﻿namespace ERP_Domians.Models
{
    public class TbOrderStatus_Supplier
    {
        public int OrderStatusId { get; set; }
        public string OrderStatusName { get; set; }
    }
}