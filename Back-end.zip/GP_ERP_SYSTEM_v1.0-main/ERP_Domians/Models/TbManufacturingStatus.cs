﻿namespace ERP_Domians.Models
{
    public class TbManufacturingStatus
    {
        public TbManufacturingStatus()
        {
                
        }

        public int statusId { get; set; }
        public string statusName { get; set; }
    }
}