import React from 'react'

const Analysis = () => {
  return (
    <div>Analysis</div>
  )
}

export default Analysis